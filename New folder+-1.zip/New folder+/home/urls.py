
from django.contrib import admin
from django.urls import path
from home import views
urlpatterns = [
    path('', views.user_login, name='user_login'),
    path('user_login', views.user_login, name='user_login'),
    path('user_signup', views.user_signup, name='user_signup'),
    path('home', views.home, name='home'),
    path('excel', views.excel, name='excel'),   
    path('remove', views.remove, name='remove'),
    path('setCourceOutcome', views.setCourceOutcome, name='setCourceOutcome'),
    path('setPaper', views.setPaper, name='setPaper'),
    path('displayPaper', views.displayPaper, name='displayPaper'),
    path('insertMarks', views.insertMarks, name='insertMarks'),
    path('updateMarks', views.updateMarks, name='updateMarks'),
    path('student', views.student, name='student'),


]
