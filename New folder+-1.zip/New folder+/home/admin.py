from django.contrib import admin
from .models import Marks
from .models import Course
# Register your models here.

#admin.site.register(Marks)
#admin.site.register(Course)